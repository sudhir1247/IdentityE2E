package com.qa.mystepdefs;
import io.cucumber.java.en.Given;
import pages.Testrr;

public class CarValuationSteps {
  Testrr testrr = new Testrr();


  @Given("this is a test line")
  public void thisIsATestLine() {
      testrr.testFunction();
  }
}