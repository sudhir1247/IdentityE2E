package pages;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.MimeMultipart;
import java.util.regex.*;

  public class ReadEmail{
    public void readEmailGmail() {
      String host = "imap.gmail.com"; // e.g., imap.gmail.com
      String username = "uone121@gmail.com";
      String password = "Testing@123";

      Properties properties = new Properties();
      properties.put("mail.store.protocol", "imaps");

      try {
        Session emailSession = Session.getDefaultInstance(properties);
        Store store = emailSession.getStore("imaps");
        store.connect(host, username, password);

        Folder emailFolder = store.getFolder("INBOX");
        emailFolder.open(Folder.READ_ONLY);

        Message[] messages = emailFolder.getMessages();
        for (Message message : messages) {
          if (message.getSubject().equalsIgnoreCase("sign in to motorway")) {
            String content = getTextFromMessage(message);
            String link = extractFirstLink(content);
            if (link != null) {
              System.out.println("Found link: " + link);
            } else {
              System.out.println("No link found in the email.");
            }
            break;
          }
        }

        emailFolder.close(false);
        store.close();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    private static String getTextFromMessage(Message message) throws Exception {
      if (message.isMimeType("text/plain")) {
        return message.getContent().toString();
      } else if (message.isMimeType("multipart/*")) {
        MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
        return getTextFromMimeMultipart(mimeMultipart);
      }
      return "";
    }

    private static String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws Exception {
      StringBuilder result = new StringBuilder();
      int count = mimeMultipart.getCount();
      for (int i = 0; i < count; i++) {
        BodyPart bodyPart = mimeMultipart.getBodyPart(i);
        if (bodyPart.isMimeType("text/plain")) {
          result.append(bodyPart.getContent());
        } else if (bodyPart.isMimeType("text/html")) {
          String html = (String) bodyPart.getContent();
          result.append(html);
        }
      }
      return result.toString();
    }

    private static String extractFirstLink(String content) {
      String regex = "http[s]?://\\S+";
      Pattern pattern = Pattern.compile(regex);
       Matcher matcher = pattern.matcher(content);
      if (matcher.find()) {
        return matcher.group();
      }
      return null;
    }
  }