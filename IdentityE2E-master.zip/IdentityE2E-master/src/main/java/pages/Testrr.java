package pages;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Testrr {

  WebDriver driver;
  ReadEmail readEmail = new ReadEmail();

  public void testFunction() {
    System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
    driver = new ChromeDriver();
    driver.get("https://autotrader.co.uk/");
    driver.manage().window().maximize();

   // driver.findElement(By.xpath("//*[@id=\"notice\"]/div[4]/button[3]")).click();
   // RegistrationNumberExtractor();
    autotrader();
  }

  public void RegistrationNumberExtractor() {
    String fileName = "car_input.txt";
    try (
        BufferedReader br = new BufferedReader(new FileReader(fileName))) {
      String line;
      while ((line = br.readLine()) != null) {
        String[] parts = line.split(",");
        if (parts.length > 1) {
          String regNumber = parts[0].trim();
          if (!regNumber.equals("regNumber")) {
            System.out.println("Registration Number: " + regNumber);
            driver.findElement(By.xpath("//input[@id='vrm-input']")).sendKeys(regNumber);
            driver.findElement(
                    By.xpath("//button[@data-thc-button='true']//span[@class='Button-module__label-SKEy'][normalize-space()='Value your car']"))
                .click();
            Thread.sleep(3000);
            driver.findElement(By.xpath("//span[normalize-space()='Confirm mileage']")).click();
            Thread.sleep(3000);
            driver.findElement(By.xpath("//input[@id='email']")).sendKeys("uone121@gmail.com");
            driver.findElement(By.xpath("//span[normalize-space()='Continue']")).click();
            Thread.sleep(3000);
            driver.findElement(By.xpath("//a[normalize-space()='Gmail']")).click();
            Thread.sleep(3000);
            driver.findElement(By.cssSelector("#identifierId")).sendKeys("uone121@gmail.com");
           // driver.findElement(By.xpath("//input[@id='identifierId']")).sendKeys("uone121@gmail.com");
            driver.findElement(By.xpath("//span[normalize-space()='Next']")).click();
            Thread.sleep(3000);
            driver.findElement(By.xpath("//input[@name='Passwd']")).sendKeys("Testing@123");
            driver.findElement(By.xpath("//span[normalize-space()='Next']")).click();



          }
        }
      }


    } catch (
        IOException e) {
      e.printStackTrace();
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }


  public void autotrader()
  {
    {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        WebElement element = driver.findElement(By.cssSelector(".buZjWW"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.tagName("body"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element, 0, 0).perform();
    }
    driver.findElement(By.cssSelector(".buZjWW > .atds-svg")).click();
    driver.findElement(By.cssSelector(".email-icon")).click();
    {
      WebElement element = driver.findElement(By.cssSelector(".fYQTAn"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    driver.findElement(By.id("email")).sendKeys("msudhirvarma@gmail.com");
    driver.findElement(By.id("password")).sendKeys("Hyderabad@15");
    driver.findElement(By.cssSelector(".at__sc-1puh6o-1")).click();
    driver.findElement(By.cssSelector(".fYQTAn")).click();
    driver.findElement(By.linkText("Value your car")).click();
    driver.findElement(By.id("valuations-reg")).click();

    driver.findElement(By.id("valuations-reg")).sendKeys("SG18 HTN");
    driver.findElement(By.id("valuations-mileage")).sendKeys("70000");

    driver.findElement(By.cssSelector(".jLOVaz")).click();
    try {
      Thread.sleep(3000);
    } catch (InterruptedException e) {
      throw new RuntimeException(e);
    }
    driver.findElement(By.cssSelector("main#content.main__content div.at__sc-18gq5du-11 button.at__sc-1n64n0d-7.atds-button.atds-type-fiesta")).click();
  }
  }

